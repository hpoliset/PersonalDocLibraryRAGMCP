"""Indexing helpers for the Personal Document Library."""
